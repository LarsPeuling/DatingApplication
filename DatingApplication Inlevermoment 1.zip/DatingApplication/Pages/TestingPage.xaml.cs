namespace DatingApplication.Pages;

public partial class TestingPage : ContentPage
{
	public TestingPage()
	{
		InitializeComponent();
	}
}